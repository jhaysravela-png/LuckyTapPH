
# Lucky Tap PH - Complete Android Studio Project

## Setup
1. Open in Android Studio Hedgehog+ (SDK 35)
2. Add Firebase: Place your google-services.json in app/
3. Replace AdMob test IDs in AndroidManifest.xml and AdMobManager.kt with real IDs
4. Sync Gradle, Build

## Features Implemented
- Gold coin tap with scale animation, combo system (800ms window), critical tap 5%+upgrade
- Level system XP = 100*level^1.35, XP bar
- Daily Reward (24h), Lucky Spin every 12h
- Missions Daily/Lifetime, Achievements, Shop upgrades (Double, Auto, Critical, Speed)
- Offline progress via Room + lastLogin calc
- DataStore for settings (dark mode, sound, vibration)
- Firebase Anonymous Auth + Firestore leaderboard
- AdMob Banner, Interstitial, Rewarded, AppOpen
- SoundManager (add raw/tap.wav etc), HapticManager
- Dark Mode, Settings, Stats, Material 3, SplashScreen, Navigation Compose

## Build
compileSdk 35, minSdk 24, target 35, Kotlin, Material3

Replace test ad units before Play Store release.
