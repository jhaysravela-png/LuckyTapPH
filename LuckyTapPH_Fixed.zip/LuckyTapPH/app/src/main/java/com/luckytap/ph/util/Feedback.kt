
package com.luckytap.ph.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class SoundManager(context: Context) {
    private val soundPool = SoundPool.Builder().setMaxStreams(5)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .build()
    private var tapId: Int = 0
    private var critId: Int = 0
    private var coinId: Int = 0
    var enabled = true

    init {
        // Using system sounds fallback, in production add res/raw/*.wav
        // For buildability we load placeholder IDs, will be 0 if not found
        try {
            val res = context.resources
            tapId = soundPool.load(context, res.getIdentifier("tap", "raw", context.packageName), 1)
            critId = soundPool.load(context, res.getIdentifier("critical", "raw", context.packageName), 1)
            coinId = soundPool.load(context, res.getIdentifier("coin", "raw", context.packageName), 1)
        } catch (e: Exception) {}
    }
    fun playTap() { if(enabled && tapId!=0) soundPool.play(tapId,1f,1f,0,0,1f) }
    fun playCrit() { if(enabled && critId!=0) soundPool.play(critId,1f,1f,0,0,1.2f) else if(enabled) playTap() }
    fun release() { soundPool.release() }
}

class HapticManager(context: Context) {
    private val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    var enabled = true
    fun tap() {
        if(!enabled) return
        vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
    }
    fun critical() {
        if(!enabled) return
        vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,40,20,60), -1))
    }
}
