
package com.luckytap.ph.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.luckytap.ph.viewmodel.GameViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

@Composable
fun ShopScreen(vm: GameViewModel, onBack: ()->Unit) {
    val state by vm.gameState.collectAsState()
    Scaffold(topBar={ TopAppBar(title={Text("Shop")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Text("Coins: ${state?.coins}", style=MaterialTheme.typography.headlineSmall) }
            item { ShopItem("Double Coins x2", "Cost: ${500*( (state?.doubleCoinsLevel?:0)+1)}", state?.doubleCoinsLevel?:0) { vm.buyUpgrade("double") } }
            item { ShopItem("Auto Tap", "Cost: ${1000*((state?.autoTapLevel?:0)+1)}", state?.autoTapLevel?:0) { vm.buyUpgrade("auto") } }
            item { ShopItem("Critical Chance +2%", "Cost: ${800*((state?.criticalChanceLevel?:0)+1)}", state?.criticalChanceLevel?:0) { vm.buyUpgrade("critical") } }
            item { ShopItem("Tap Speed +10%", "Cost: ${600*((state?.tapSpeedLevel?:0)+1)}", state?.tapSpeedLevel?:0) { vm.buyUpgrade("speed") } }
        }
    }
}

@Composable
fun ShopItem(title: String, desc: String, level: Int, onBuy: ()->Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Column { Text(title, style=MaterialTheme.typography.titleMedium); Text(desc); Text("Lvl $level") }
            Button(onClick=onBuy) { Text("Buy") }
        }
    }
}

@Composable
fun SettingsScreen(vm: GameViewModel, onBack: ()->Unit) {
    val dark by vm.darkMode.collectAsState()
    val sound by vm.soundEnabled.collectAsState()
    val vib by vm.vibEnabled.collectAsState()
    Scaffold(topBar={ TopAppBar(title={Text("Settings")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Dark Mode"); Switch(checked=dark, onCheckedChange={ vm.toggleDark(it) }) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Sound"); Switch(checked=sound, onCheckedChange={ vm.toggleSound(it) }) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Vibration"); Switch(checked=vib, onCheckedChange={ vm.toggleVib(it) }) }
            Text("Firebase Anonymous Auth enabled. Firestore leaderboard syncs automatically.")
            Text("AdMob IDs are TEST IDs - replace in AndroidManifest and AdMobManager before release.")
        }
    }
}

@Composable
fun StatsScreen(vm: GameViewModel, onBack: ()->Unit) {
    val s by vm.gameState.collectAsState()
    Scaffold(topBar={ TopAppBar(title={Text("Statistics")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Total Taps: ${s?.totalTaps}")
            Text("Lifetime Coins: ${s?.lifetimeCoins}")
            Text("Best Combo: ${s?.bestCombo}")
            Text("Level: ${s?.level}")
            Text("Total XP: ${s?.totalXp}")
        }
    }
}

@Composable
fun MissionsScreen(vm: GameViewModel, onBack: ()->Unit) {
    val missions by vm.missions.collectAsState()
    Scaffold(topBar={ TopAppBar(title={Text("Missions & Achievements")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(missions) { m ->
                Card(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(12.dp)){
                        Text("${m.title} [${m.type}]", style=MaterialTheme.typography.titleSmall)
                        LinearProgressIndicator(progress={ m.progress.toFloat()/m.target.coerceAtLeast(1) }, modifier=Modifier.fillMaxWidth().padding(vertical=4.dp))
                        Text("${m.progress}/${m.target} - Reward ${m.reward} ${if(m.completed)"✅" else ""}")
                    }
                }
            }
        }
    }
}

@Composable
fun LeaderboardScreen(onBack: ()->Unit) {
    var list by remember { mutableStateOf<List<Map<String,Any>>>(emptyList()) }
    LaunchedEffect(Unit) {
        try {
            val snap = FirebaseFirestore.getInstance().collection("leaderboard").orderBy("coins", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(20).get().await()
            list = snap.documents.map { it.data ?: emptyMap() }
        } catch (e: Exception) {}
    }
    Scaffold(topBar={ TopAppBar(title={Text("Leaderboard")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp)) {
            items(list.size) { i ->
                val d = list[i]
                Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Row(Modifier.padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween){ Text("#${i+1} ${d["name"]}") ; Text("${d["coins"]}") } }
            }
            if(list.isEmpty()) item { Text("No data yet. Play to appear! (Requires google-services.json)") }
        }
    }
}

@Composable
fun SpinScreen(vm: GameViewModel, onBack: ()->Unit) {
    var result by remember { mutableStateOf<Int?>(null) }
    Scaffold(topBar={ TopAppBar(title={Text("Lucky Spin - Every 12h")}, navigationIcon={ IconButton(onClick=onBack){ Text("←") } }) }) { p ->
        Column(Modifier.padding(p).padding(24.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Text("Spin the wheel!")
            Button(onClick={
                if(vm.canSpin()) result = vm.doSpin() else result = -1
            }, enabled=vm.canSpin()) { Text(if(vm.canSpin()) "SPIN!" else "Come back in 12h") }
            result?.let { if(it==-1) Text("Not ready yet") else Text("You won $it coins! 🎉", style=MaterialTheme.typography.headlineMedium) }
        }
    }
}
