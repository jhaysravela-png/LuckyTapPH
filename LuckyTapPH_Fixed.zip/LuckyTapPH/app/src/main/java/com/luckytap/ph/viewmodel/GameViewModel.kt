
package com.luckytap.ph.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.luckytap.ph.data.local.*
import com.luckytap.ph.data.repo.GameRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.pow
import kotlin.random.Random

data class TapResult(val coinsEarned: Long, val isCritical: Boolean, val combo: Int)

class GameViewModel(app: Application): AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val repo = GameRepository(db.gameDao())
    private val prefs = PrefsManager(app)

    val gameState = repo.stateFlow().stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val achievements = repo.achievements().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val missions = repo.missions().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val darkMode = prefs.darkMode.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val soundEnabled = prefs.sound.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val vibEnabled = prefs.vibration.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    private var lastTapTime = 0L
    private var combo = 0
    private var comboJob: Job? = null
    private var autoTapJob: Job? = null

    val currentCombo = MutableStateFlow(0)
    val lastTapResult = MutableStateFlow<TapResult?>(null)

    init {
        viewModelScope.launch { repo.ensureDefaults() }
        startAutoTap()
    }

    fun toggleDark(v: Boolean) = viewModelScope.launch { prefs.setDarkMode(v) }
    fun toggleSound(v: Boolean) = viewModelScope.launch { prefs.setSound(v) }
    fun toggleVib(v: Boolean) = viewModelScope.launch { prefs.setVibration(v) }

    fun xpForNextLevel(level: Int): Long = (100 * level.toDouble().pow(1.35)).toLong()

    fun onTap() {
        val now = System.currentTimeMillis()
        if(now - lastTapTime < 800) combo++ else combo = 1
        lastTapTime = now
        currentCombo.value = combo
        comboJob?.cancel()
        comboJob = viewModelScope.launch {
            delay(1500)
            combo = 0
            currentCombo.value = 0
        }

        viewModelScope.launch {
            val state = repo.getState()
            val critChance = 0.05 + state.criticalChanceLevel * 0.02
            val isCrit = Random.nextDouble() < critChance
            val base = 1L
            val doubleMult = if(state.doubleCoinsLevel>0) 2.0 else 1.0
            val tapSpeedMult = 1.0 + state.tapSpeedLevel * 0.1
            val comboMult = 1.0 + (combo.coerceAtMost(20) * 0.05)
            val critMult = if(isCrit) 5.0 else 1.0
            val earned = (base * doubleMult * tapSpeedMult * comboMult * critMult).toLong().coerceAtLeast(1)

            var newXp = state.xp + earned
            var newLevel = state.level
            var xpNeeded = xpForNextLevel(newLevel)
            while(newXp >= xpNeeded) {
                newXp -= xpNeeded
                newLevel++
                xpNeeded = xpForNextLevel(newLevel)
            }

            repo.update {
                it.copy(
                    coins = it.coins + earned,
                    totalTaps = it.totalTaps + 1,
                    xp = newXp,
                    totalXp = it.totalXp + earned,
                    lifetimeCoins = it.lifetimeCoins + earned,
                    level = newLevel,
                    bestCombo = maxOf(it.bestCombo, combo)
                )
            }
            lastTapResult.value = TapResult(earned, isCrit, combo)
            checkMissions(earned, isCrit)
            if(Random.nextInt(20)==0) repo.syncLeaderboard(repo.getState().coins)
        }
    }

    private suspend fun checkMissions(earned: Long, isCrit: Boolean) {
        // naive progress update
        val all = db.gameDao().getMissions().first()
        all.forEach { m ->
            var newProg = m.progress
            when(m.id) {
                "daily_tap_100" -> newProg = (m.progress + 1).coerceAtMost(m.target)
                "daily_crit_5" -> if(isCrit) newProg = (m.progress+1).coerceAtMost(m.target)
                "life_tap_10k" -> newProg = (m.progress+1).coerceAtMost(m.target)
            }
            if(newProg!=m.progress) db.gameDao().saveMission(m.copy(progress=newProg, completed=newProg>=m.target))
        }
    }

    fun claimDailyReward(): Long {
        val now = System.currentTimeMillis()
        var reward = 0L
        viewModelScope.launch {
            val s = repo.getState()
            if(now - s.lastDailyReward > 24*60*60*1000) {
                reward = 100L * (s.consecutiveDays + 1)
                repo.update { it.copy(coins=it.coins+reward, lastDailyReward=now, consecutiveDays=it.consecutiveDays+1) }
            }
        }
        return reward
    }

    fun canSpin(): Boolean {
        val s = gameState.value ?: return false
        return System.currentTimeMillis() - s.lastSpin > 12*60*60*1000
    }

    fun doSpin(): Int {
        val prize = listOf(50,100,200,500,1000).random()
        viewModelScope.launch {
            repo.update { it.copy(coins=it.coins+prize, lastSpin=System.currentTimeMillis()) }
        }
        return prize
    }

    fun buyUpgrade(type: String) {
        viewModelScope.launch {
            val s = repo.getState()
            val cost = when(type) {
                "double" -> 500 * (s.doubleCoinsLevel+1)
                "auto" -> 1000 * (s.autoTapLevel+1)
                "critical" -> 800 * (s.criticalChanceLevel+1)
                "speed" -> 600 * (s.tapSpeedLevel+1)
                else -> 999999
            }
            if(s.coins >= cost) {
                repo.update {
                    when(type) {
                        "double" -> it.copy(coins=it.coins-cost, doubleCoinsLevel=it.doubleCoinsLevel+1)
                        "auto" -> it.copy(coins=it.coins-cost, autoTapLevel=it.autoTapLevel+1)
                        "critical" -> it.copy(coins=it.coins-cost, criticalChanceLevel=it.criticalChanceLevel+1)
                        "speed" -> it.copy(coins=it.coins-cost, tapSpeedLevel=it.tapSpeedLevel+1)
                        else -> it
                    }
                }
                if(type=="auto") startAutoTap()
            }
        }
    }

    private fun startAutoTap() {
        autoTapJob?.cancel()
        autoTapJob = viewModelScope.launch {
            while(true) {
                val s = repo.getState()
                if(s.autoTapLevel>0) {
                    delay((1000L / s.autoTapLevel.coerceAtLeast(1)).coerceAtLeast(200))
                    // auto earns
                    repo.update { it.copy(coins=it.coins + s.autoTapLevel, lifetimeCoins=it.lifetimeCoins + s.autoTapLevel) }
                } else delay(1000)
            }
        }
    }

    fun offlineProgress() {
        viewModelScope.launch {
            val s = repo.getState()
            val elapsed = (System.currentTimeMillis() - s.lastLogin)/1000
            if(elapsed>10 && s.autoTapLevel>0) {
                val earned = elapsed * s.autoTapLevel * 0.5
                repo.update { it.copy(coins=it.coins+earned.toLong(), lifetimeCoins=it.lifetimeCoins+earned.toLong(), lastLogin=System.currentTimeMillis()) }
            } else {
                repo.update { it.copy(lastLogin=System.currentTimeMillis()) }
            }
        }
    }
}
