
package com.luckytap.ph.util

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class AdMobManager(private val context: Context) {
    // TEST IDs - REPLACE BEFORE RELEASE
    private val BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private val INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private val REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    var interstitial: InterstitialAd? = null
    var rewarded: RewardedAd? = null

    fun loadInterstitial() {
        InterstitialAd.load(context, INTERSTITIAL_ID, AdRequest.Builder().build(), object: InterstitialAdLoadCallback(){
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
        })
    }
    fun showInterstitial(activity: Activity) {
        interstitial?.show(activity)
        loadInterstitial()
    }
    fun loadRewarded() {
        RewardedAd.load(context, REWARDED_ID, AdRequest.Builder().build(), object: RewardedAdLoadCallback(){
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
        })
    }
    fun showRewarded(activity: Activity, onReward: (Int)->Unit) {
        rewarded?.show(activity) { onReward(500) }
        loadRewarded()
    }
    fun bannerAdRequest() = AdRequest.Builder().build()
    fun bannerId() = BANNER_ID
}

class AppOpenAdManager(private val app: Application): Application.ActivityLifecycleCallbacks {
    private var appOpenAd: AppOpenAd? = null
    private val AD_ID = "ca-app-pub-3940256099942544/9257395921"
    private var currentActivity: Activity? = null
    init { app.registerActivityLifecycleCallbacks(this) }
    fun load() {
        AppOpenAd.load(app, AD_ID, AdRequest.Builder().build(), AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, object: AppOpenAd.AppOpenAdLoadCallback(){
            override fun onAdLoaded(ad: AppOpenAd) { appOpenAd = ad }
        })
    }
    fun showIfAvailable() {
        currentActivity?.let { act ->
            appOpenAd?.show(act)
            appOpenAd = null
            load()
        }
    }
    override fun onActivityResumed(a: Activity) { currentActivity = a }
    override fun onActivityStarted(a: Activity) { currentActivity = a }
    override fun onActivityCreated(a: Activity, b: Bundle?) {}
    override fun onActivityPaused(a: Activity) {}
    override fun onActivityStopped(a: Activity) {}
    override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
    override fun onActivityDestroyed(a: Activity) { if(currentActivity==a) currentActivity=null }
}
