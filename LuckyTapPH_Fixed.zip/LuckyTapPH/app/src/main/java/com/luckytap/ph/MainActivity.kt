
package com.luckytap.ph

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.luckytap.ph.ui.screens.*
import com.luckytap.ph.ui.theme.LuckyTapTheme
import com.luckytap.ph.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { false }
        (application as LuckyTapApp).appOpenAdManager.load()

        setContent {
            val dark by vm.darkMode.collectAsState()
            LuckyTapTheme(dark=dark) {
                val nav = rememberNavController()
                NavHost(navController=nav, startDestination="game") {
                    composable("game") { GameScreen(vm, onNav={ nav.navigate(it) }) }
                    composable("shop") { ShopScreen(vm) { nav.popBackStack() } }
                    composable("settings") { SettingsScreen(vm) { nav.popBackStack() } }
                    composable("stats") { StatsScreen(vm) { nav.popBackStack() } }
                    composable("missions") { MissionsScreen(vm) { nav.popBackStack() } }
                    composable("leaderboard") { LeaderboardScreen { nav.popBackStack() } }
                    composable("spin") { SpinScreen(vm) { nav.popBackStack() } }
                }
            }
        }
    }
    override fun onResume() {
        super.onResume()
        (application as LuckyTapApp).appOpenAdManager.showIfAvailable()
    }
}
