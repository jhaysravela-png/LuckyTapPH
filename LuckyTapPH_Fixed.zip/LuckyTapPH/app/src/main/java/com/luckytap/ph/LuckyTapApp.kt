
package com.luckytap.ph

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.google.firebase.FirebaseApp
import com.luckytap.ph.util.AppOpenAdManager

class LuckyTapApp : Application() {
    lateinit var appOpenAdManager: AppOpenAdManager
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        MobileAds.initialize(this) {}
        appOpenAdManager = AppOpenAdManager(this)
    }
}
