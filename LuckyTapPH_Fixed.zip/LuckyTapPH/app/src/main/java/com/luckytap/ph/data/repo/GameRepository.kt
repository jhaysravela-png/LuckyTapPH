
package com.luckytap.ph.data.repo

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.luckytap.ph.data.local.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await

class GameRepository(private val dao: GameDao) {
    fun stateFlow(): Flow<GameState?> = dao.getGameStateFlow()
    suspend fun getState(): GameState = dao.getGameState() ?: GameState()

    suspend fun update(transform: (GameState)->GameState) {
        val cur = getState()
        dao.saveGameState(transform(cur))
    }

    fun achievements(): Flow<List<AchievementEntity>> = dao.getAchievements()
    fun missions(): Flow<List<MissionEntity>> = dao.getMissions()

    suspend fun ensureDefaults() {
        if(dao.getGameState()==null) dao.saveGameState(GameState())
        val ach = listOf(
            AchievementEntity("tap_100","Beginner Tapper","Tap 100 times", target=100),
            AchievementEntity("tap_1000","Tap Master","Tap 1000 times", target=1000),
            AchievementEntity("coins_10k","Rich","Earn 10k coins", target=10000),
            AchievementEntity("combo_20","Combo King","20x combo", target=20),
            AchievementEntity("level_10","Level 10","Reach level 10", target=10)
        )
        ach.forEach { dao.saveAchievement(it) }
        val daily = listOf(
            MissionEntity("daily_tap_100","Tap 100 times","DAILY",100, reward=200),
            MissionEntity("daily_crit_5","5 Critical Taps","DAILY",5, reward=300),
            MissionEntity("daily_spin","Spin the wheel","DAILY",1, reward=150)
        )
        daily.forEach { dao.saveMission(it) }
        val lifetime = listOf(
            MissionEntity("life_tap_10k","10,000 Taps","LIFETIME",10000, reward=1000),
            MissionEntity("life_coins_100k","100k Coins","LIFETIME",100000, reward=5000)
        )
        lifetime.forEach { dao.saveMission(it) }
    }

    suspend fun syncLeaderboard(coins: Long) {
        try {
            val auth = FirebaseAuth.getInstance()
            if(auth.currentUser==null) auth.signInAnonymously().await()
            val uid = auth.currentUser?.uid ?: return
            FirebaseFirestore.getInstance().collection("leaderboard").document(uid)
                .set(mapOf("coins" to coins, "updated" to System.currentTimeMillis(), "name" to "Player_${'$'}{uid.take(4)}")).await()
        } catch (e: Exception) {}
    }
}
