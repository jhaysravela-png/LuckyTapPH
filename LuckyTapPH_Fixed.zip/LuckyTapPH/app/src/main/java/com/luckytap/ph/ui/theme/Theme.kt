
package com.luckytap.ph.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightScheme = lightColorScheme(
    primary = Color(0xFF8B6914),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDF9E),
    secondary = Color(0xFF6F5D40),
    tertiary = Color(0xFF4F6543),
    background = Color(0xFFFFF8F0),
    surface = Color(0xFFFFF8F0),
    error = Color(0xFFBA1A1A)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFFD700),
    onPrimary = Color(0xFF3A2F00),
    primaryContainer = Color(0xFF5C4300),
    secondary = Color(0xFFDCC6A1),
    background = Color(0xFF1A1C15),
    surface = Color(0xFF1A1C15)
)

@Composable
fun LuckyTapTheme(dark: Boolean, content: @Composable ()->Unit) {
    MaterialTheme(colorScheme = if(dark) DarkScheme else LightScheme, content = content)
}
