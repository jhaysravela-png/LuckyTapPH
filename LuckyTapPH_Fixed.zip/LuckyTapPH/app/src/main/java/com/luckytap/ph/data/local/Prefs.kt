
package com.luckytap.ph.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore("lucky_tap_prefs")

object PrefKeys {
    val DARK_MODE = booleanPreferencesKey("dark_mode")
    val SOUND = booleanPreferencesKey("sound")
    val VIBRATION = booleanPreferencesKey("vibration")
    val USER_ID = stringPreferencesKey("user_id")
}

class PrefsManager(private val ctx: Context) {
    val darkMode: Flow<Boolean> = ctx.dataStore.data.map { it[PrefKeys.DARK_MODE] ?: false }
    val sound: Flow<Boolean> = ctx.dataStore.data.map { it[PrefKeys.SOUND] ?: true }
    val vibration: Flow<Boolean> = ctx.dataStore.data.map { it[PrefKeys.VIBRATION] ?: true }

    suspend fun setDarkMode(v: Boolean) { ctx.dataStore.edit { it[PrefKeys.DARK_MODE]=v } }
    suspend fun setSound(v: Boolean) { ctx.dataStore.edit { it[PrefKeys.SOUND]=v } }
    suspend fun setVibration(v: Boolean) { ctx.dataStore.edit { it[PrefKeys.VIBRATION]=v } }
}
