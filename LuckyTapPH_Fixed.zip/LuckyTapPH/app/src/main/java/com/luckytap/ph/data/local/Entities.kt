
package com.luckytap.ph.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_state")
data class GameState(
    @PrimaryKey val id: Int = 0,
    val coins: Long = 0,
    val totalTaps: Long = 0,
    val level: Int = 1,
    val xp: Long = 0,
    val totalXp: Long = 0,
    val doubleCoinsLevel: Int = 0,
    val autoTapLevel: Int = 0,
    val criticalChanceLevel: Int = 0,
    val tapSpeedLevel: Int = 0,
    val lastDailyReward: Long = 0,
    val lastSpin: Long = 0,
    val consecutiveDays: Int = 0,
    val lifetimeCoins: Long = 0,
    val bestCombo: Int = 0,
    val lastLogin: Long = System.currentTimeMillis()
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val desc: String,
    val unlocked: Boolean = false,
    val progress: Int = 0,
    val target: Int = 100
)

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String, // DAILY, LIFETIME
    val target: Int,
    val progress: Int = 0,
    val completed: Boolean = false,
    val reward: Long = 100
)
