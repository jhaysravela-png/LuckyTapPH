
package com.luckytap.ph.ui.screens

import android.app.Activity
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.luckytap.ph.util.AdMobManager
import com.luckytap.ph.util.HapticManager
import com.luckytap.ph.util.SoundManager
import com.luckytap.ph.viewmodel.GameViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(vm: GameViewModel, onNav: (String)->Unit) {
    val state by vm.gameState.collectAsState()
    val combo by vm.currentCombo.collectAsState()
    val lastTap by vm.lastTapResult.collectAsState()
    val dark by vm.darkMode.collectAsState()
    val soundOn by vm.soundEnabled.collectAsState()
    val vibOn by vm.vibEnabled.collectAsState()

    val ctx = LocalContext.current
    val activity = ctx as Activity
    val sound = remember { SoundManager(ctx).apply{ enabled = soundOn } }
    val haptic = remember { HapticManager(ctx).apply{ enabled = vibOn } }
    val ads = remember { AdMobManager(ctx) }

    LaunchedEffect(soundOn) { sound.enabled = soundOn }
    LaunchedEffect(vibOn) { haptic.enabled = vibOn }
    LaunchedEffect(Unit) { vm.offlineProgress(); ads.loadInterstitial(); ads.loadRewarded() }

    var scaleAnim by remember { mutableStateOf(1f) }
    val scale by animateFloatAsState(targetValue = scaleAnim, animationSpec = spring(dampingRatio = 0.4f, stiffness = 600f), label="coinScale")

    LaunchedEffect(lastTap) {
        if(lastTap!=null) {
            scaleAnim = 0.85f
            delay(80)
            scaleAnim = 1f
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Lucky Tap PH 🇵🇭") },
                actions = {
                    IconButton(onClick={ onNav("stats") }) { Icon(Icons.Default.BarChart, null) }
                    IconButton(onClick={ onNav("shop") }) { Icon(Icons.Default.ShoppingCart, null) }
                    IconButton(onClick={ onNav("settings") }) { Icon(Icons.Default.Settings, null) }
                })
        },
        bottomBar = {
            Column {
                AndroidView(factory = { c ->
                    AdView(c).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = ads.bannerId()
                        loadAd(AdRequest.Builder().build())
                    }
                }, modifier = Modifier.fillMaxWidth().height(50.dp))
                NavigationBar {
                    NavigationBarItem(icon={Icon(Icons.Default.Home,null)}, label={Text("Tap")}, selected=true, onClick={})
                    NavigationBarItem(icon={Icon(Icons.Default.Star,null)}, label={Text("Missions")}, selected=false, onClick={ onNav("missions") })
                    NavigationBarItem(icon={Icon(Icons.Default.Leaderboard,null)}, label={Text("Board")}, selected=false, onClick={ onNav("leaderboard") })
                    NavigationBarItem(icon={Icon(Icons.Default.Casino,null)}, label={Text("Spin")}, selected=false, onClick={ onNav("spin") })
                }
            }
        }
    ) { pad ->
        LazyColumn(modifier=Modifier.padding(pad).fillMaxSize().padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            item {
                Card(modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Coins: ${state?.coins ?: 0}", fontSize=28.sp, fontWeight=FontWeight.Bold)
                        LinearProgressIndicator(progress={ ((state?.xp ?: 0).toFloat() / vm.xpForNextLevel(state?.level?:1).coerceAtLeast(1).toFloat()).coerceIn(0f,1f) }, modifier=Modifier.fillMaxWidth().padding(top=8.dp))
                        Text("Level ${state?.level ?: 1} - ${state?.xp ?: 0} / ${vm.xpForNextLevel(state?.level?:1)} XP", style=MaterialTheme.typography.bodySmall)
                        if(combo>1) Text("COMBO x$combo 🔥", color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Black, fontSize=20.sp, modifier=Modifier.padding(top=4.dp))
                        if(lastTap?.isCritical==true) Text("CRITICAL! +${lastTap?.coinsEarned}!", color=MaterialTheme.colorScheme.error, fontWeight=FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(32.dp))
                Card(modifier=Modifier.size(220.dp).scale(scale).clip(CircleShape).clickable{
                    vm.onTap()
                    if(lastTap?.isCritical==true) { sound.playCrit(); haptic.critical() } else { sound.playTap(); haptic.tap() }
                }, shape=CircleShape, elevation=CardDefaults.cardElevation(12.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
                    Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                        Text("🪙", fontSize=96.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick={ vm.claimDailyReward() }) { Text("Daily Reward") }
                    FilledTonalButton(onClick={ if(vm.canSpin()) onNav("spin") else {} }) { Text(if(vm.canSpin()) "Lucky Spin Ready!" else "Spin (12h)") }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={ ads.showInterstitial(activity) }) { Text("Interstitial") }
                    Button(onClick={ ads.showRewarded(activity){ vm.doSpin() } }) { Text("Rewarded +500") }
                }
                Spacer(Modifier.height(16.dp))
                Text("Double: ${state?.doubleCoinsLevel} | Auto: ${state?.autoTapLevel} | Crit: ${state?.criticalChanceLevel} | Speed: ${state?.tapSpeedLevel}")
            }
        }
    }
}
