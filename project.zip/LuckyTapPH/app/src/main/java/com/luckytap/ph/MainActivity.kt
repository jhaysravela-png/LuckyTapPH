
package com.luckytap.ph

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

class MainActivity: ComponentActivity(){
    private val vm: GameViewModel by viewModels()
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContent{
            val dark by vm.dark.collectAsState()
            val coins by vm.coins.collectAsState()
            val level by vm.level.collectAsState()
            val xp by vm.xp.collectAsState()
            val nav = rememberNavController()
            val colorScheme = if(dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFFFD700)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF8B6914))
            MaterialTheme(colorScheme=colorScheme){
                NavHost(navController=nav, startDestination="game"){
                    composable("game"){
                        val combo = vm.combo
                        val lastEarned = vm.lastEarned
                        val isCrit = vm.isCritical
                        var scaleTarget by remember{ mutableStateOf(1f) }
                        val scale by animateFloatAsState(targetValue=scaleTarget, animationSpec=spring(dampingRatio=0.4f, stiffness=600f), label="")
                        LaunchedEffect(lastEarned){ scaleTarget=0.85f; kotlinx.coroutines.delay(80); scaleTarget=1f }
                        val dl by vm.doubleLevel.collectAsState()
                        val al by vm.autoLevel.collectAsState()
                        val cl by vm.critLevel.collectAsState()
                        val sl by vm.speedLevel.collectAsState()
                        val context = LocalContext.current
                        Scaffold(
                            topBar={ TopAppBar(title={Text("Lucky Tap PH 🇵🇭")}, actions={
                                IconButton(onClick={ nav.navigate("stats") }){ Icon(Icons.Default.BarChart,null) }
                                IconButton(onClick={ nav.navigate("shop") }){ Icon(Icons.Default.ShoppingCart,null) }
                                IconButton(onClick={ nav.navigate("settings") }){ Icon(Icons.Default.Settings,null) }
                            })},
                            bottomBar={
                                Column{
                                    AndroidView(factory={ c-> AdView(c).apply{ setAdSize(AdSize.BANNER); adUnitId="ca-app-pub-3940256099942544/6300978111"; loadAd(AdRequest.Builder().build()) }}, modifier=Modifier.fillMaxWidth().height(50.dp))
                                    NavigationBar{
                                        NavigationBarItem(icon={Icon(Icons.Default.Home,null)}, label={Text("Tap")}, selected=true, onClick={})
                                        NavigationBarItem(icon={Icon(Icons.Default.Star,null)}, label={Text("Missions")}, selected=false, onClick={ nav.navigate("missions") })
                                        NavigationBarItem(icon={Icon(Icons.Default.Leaderboard,null)}, label={Text("Board")}, selected=false, onClick={ nav.navigate("leaderboard") })
                                        NavigationBarItem(icon={Icon(Icons.Default.Casino,null)}, label={Text("Spin")}, selected=false, onClick={ nav.navigate("spin") })
                                    }
                                }
                            }
                        ){ pad ->
                            Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally){
                                Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp)){
                                    Column(Modifier.padding(16.dp)){
                                        Text("Coins: $coins", fontSize=28.sp, fontWeight=FontWeight.Bold)
                                        LinearProgressIndicator(progress={ xp.toFloat()/vm.xpNeeded(level).toFloat() }, modifier=Modifier.fillMaxWidth().padding(top=8.dp))
                                        Text("Level $level - $xp / ${vm.xpNeeded(level)} XP", style=MaterialTheme.typography.bodySmall)
                                        if(combo>1) Text("COMBO x$combo 🔥", fontWeight=FontWeight.Black, fontSize=20.sp, color=MaterialTheme.colorScheme.primary)
                                        if(isCrit) Text("CRITICAL! +$lastEarned!", color=MaterialTheme.colorScheme.error, fontWeight=FontWeight.Bold)
                                    }
                                }
                                Spacer(Modifier.height(32.dp))
                                Card(Modifier.size(220.dp).scale(scale).clip(CircleShape).clickable{ vm.tap() }, shape=CircleShape, elevation=CardDefaults.cardElevation(12.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){
                                    Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center){ Text("🪙", fontSize=96.sp) }
                                }
                                Spacer(Modifier.height(24.dp))
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                                    FilledTonalButton(onClick={ vm.claimDaily() }){ Text("Daily +500") }
                                    FilledTonalButton(onClick={ if(vm.canSpin()) nav.navigate("spin") }){ Text(if(vm.canSpin()) "Spin Ready!" else "Spin (12h)") }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("Double:$dl Auto:$al Crit:$cl Speed:$sl", style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    composable("shop"){
                        val coinsVal by vm.coins.collectAsState()
                        val dl by vm.doubleLevel.collectAsState()
                        val al by vm.autoLevel.collectAsState()
                        val cl by vm.critLevel.collectAsState()
                        val sl by vm.speedLevel.collectAsState()
                        Scaffold(topBar={ TopAppBar(title={Text("Shop")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
                                Text("Coins: $coinsVal", style=MaterialTheme.typography.headlineSmall)
                                ShopItem("Double Coins x2","Cost: ${500*(dl+1)} Lvl $dl"){ vm.buy("double") }
                                ShopItem("Auto Tap","Cost: ${1000*(al+1)} Lvl $al"){ vm.buy("auto") }
                                ShopItem("Critical +2%","Cost: ${800*(cl+1)} Lvl $cl"){ vm.buy("critical") }
                                ShopItem("Tap Speed +10%","Cost: ${600*(sl+1)} Lvl $sl"){ vm.buy("speed") }
                            }
                        }
                    }
                    composable("settings"){
                        val darkVal by vm.dark.collectAsState()
                        val soundVal by vm.sound.collectAsState()
                        val vibVal by vm.vib.collectAsState()
                        Scaffold(topBar={ TopAppBar(title={Text("Settings")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Dark Mode"); Switch(checked=darkVal, onCheckedChange={ vm.setDark(it) }) }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Sound"); Switch(checked=soundVal, onCheckedChange={ vm.setSound(it) }) }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text("Vibration"); Switch(checked=vibVal, onCheckedChange={ vm.setVib(it) }) }
                                Text("AdMob TEST IDs - replace before release")
                                Text("Firebase: add google-services.json to enable leaderboard")
                            }
                        }
                    }
                    composable("stats"){
                        val tapsVal by vm.taps.collectAsState()
                        val lifetimeVal by vm.lifetime.collectAsState()
                        val bestVal by vm.bestCombo.collectAsState()
                        val totalXpVal by vm.totalXp.collectAsState()
                        Scaffold(topBar={ TopAppBar(title={Text("Statistics")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
                                Text("Total Taps: $tapsVal")
                                Text("Lifetime Coins: $lifetimeVal")
                                Text("Best Combo: $bestVal")
                                Text("Total XP: $totalXpVal")
                                Text("Level: $level")
                            }
                        }
                    }
                    composable("missions"){
                        Scaffold(topBar={ TopAppBar(title={Text("Missions & Achievements")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
                                Card(Modifier.fillMaxWidth()){ Column(Modifier.padding(12.dp)){ Text("Daily: Tap 100 times"); LinearProgressIndicator(progress={ (tapsVal % 100).toFloat()/100f }, modifier=Modifier.fillMaxWidth()) } }
                                Card(Modifier.fillMaxWidth()){ Column(Modifier.padding(12.dp)){ Text("Lifetime: 10k Taps - ${tapsVal}/10000") } }
                                Card(Modifier.fillMaxWidth()){ Column(Modifier.padding(12.dp)){ Text("Achievement: Beginner Tapper - 100 taps") } }
                            }
                        }
                    }
                    composable("leaderboard"){
                        Scaffold(topBar={ TopAppBar(title={Text("Leaderboard")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(16.dp)){ Text("Add google-services.json to enable Firebase Firestore leaderboard. Anonymous auth ready."); Text("Top players will appear here ordered by coins.") }
                        }
                    }
                    composable("spin"){
                        var result by remember{ mutableStateOf<Int?>(null) }
                        Scaffold(topBar={ TopAppBar(title={Text("Lucky Spin")}, navigationIcon={ IconButton(onClick={ nav.popBackStack() }){ Text("←") } }) }){ p ->
                            Column(Modifier.padding(p).padding(24.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){
                                Text("Spin every 12 hours!")
                                Button(onClick={ result = if(vm.canSpin()) vm.spin() else -1 }, enabled=vm.canSpin()){ Text(if(vm.canSpin()) "SPIN!" else "Wait 12h") }
                                result?.let{ if(it==-1) Text("Not ready") else Text("You won $it coins! 🎉", style=MaterialTheme.typography.headlineMedium) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShopItem(title:String, desc:String, onBuy:()->Unit){
    Card(Modifier.fillMaxWidth()){
        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
            Column{ Text(title, style=MaterialTheme.typography.titleMedium); Text(desc) }
            Button(onClick=onBuy){ Text("Buy") }
        }
    }
}
