
package com.luckytap.ph

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.pow
import kotlin.random.Random

val Application.dataStore by preferencesDataStore("lucky_tap")

class GameViewModel(app: Application): AndroidViewModel(app) {
    private val ctx = app
    object Keys {
        val COINS = longPreferencesKey("coins")
        val TAPS = longPreferencesKey("taps")
        val LEVEL = intPreferencesKey("level")
        val XP = longPreferencesKey("xp")
        val TOTAL_XP = longPreferencesKey("total_xp")
        val DOUBLE = intPreferencesKey("double")
        val AUTO = intPreferencesKey("auto")
        val CRIT = intPreferencesKey("crit")
        val SPEED = intPreferencesKey("speed")
        val LAST_DAILY = longPreferencesKey("last_daily")
        val LAST_SPIN = longPreferencesKey("last_spin")
        val BEST_COMBO = intPreferencesKey("best_combo")
        val DARK = booleanPreferencesKey("dark")
        val SOUND = booleanPreferencesKey("sound")
        val VIB = booleanPreferencesKey("vib")
        val LIFETIME = longPreferencesKey("lifetime")
    }

    val coins = ctx.dataStore.data.map { it[Keys.COINS] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val taps = ctx.dataStore.data.map { it[Keys.TAPS] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val level = ctx.dataStore.data.map { it[Keys.LEVEL] ?: 1 }.stateIn(viewModelScope, SharingStarted.Eagerly, 1)
    val xp = ctx.dataStore.data.map { it[Keys.XP] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val totalXp = ctx.dataStore.data.map { it[Keys.TOTAL_XP] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val doubleLevel = ctx.dataStore.data.map { it[Keys.DOUBLE] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val autoLevel = ctx.dataStore.data.map { it[Keys.AUTO] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val critLevel = ctx.dataStore.data.map { it[Keys.CRIT] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val speedLevel = ctx.dataStore.data.map { it[Keys.SPEED] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val bestCombo = ctx.dataStore.data.map { it[Keys.BEST_COMBO] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val lifetime = ctx.dataStore.data.map { it[Keys.LIFETIME] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val dark = ctx.dataStore.data.map { it[Keys.DARK] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val sound = ctx.dataStore.data.map { it[Keys.SOUND] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val vib = ctx.dataStore.data.map { it[Keys.VIB] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val lastDaily = ctx.dataStore.data.map { it[Keys.LAST_DAILY] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val lastSpin = ctx.dataStore.data.map { it[Keys.LAST_SPIN] ?: 0L }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)

    var combo by mutableStateOf(0)
    var lastEarned by mutableStateOf(0L)
    var isCritical by mutableStateOf(false)
    private var lastTapTime = 0L

    fun xpNeeded(lv: Int) = (100 * lv.toDouble().pow(1.35)).toLong()

    fun tap(){
        val now = System.currentTimeMillis()
        combo = if(now - lastTapTime < 800) combo+1 else 1
        lastTapTime = now
        val critChance = 0.05 + critLevel.value*0.02
        val crit = Random.nextDouble() < critChance
        isCritical = crit
        val mult = (1.0 + speedLevel.value*0.1) * (if(doubleLevel.value>0) 2.0 else 1.0) * (1.0 + combo.coerceAtMost(20)*0.05) * (if(crit) 5.0 else 1.0)
        val earned = mult.toLong().coerceAtLeast(1)
        lastEarned = earned
        viewModelScope.launch {
            ctx.dataStore.edit { p ->
                val curCoins = p[Keys.COINS] ?: 0L
                val curTaps = p[Keys.TAPS] ?: 0L
                val curXp = p[Keys.XP] ?: 0L
                val curTotal = p[Keys.TOTAL_XP] ?: 0L
                val curLv = p[Keys.LEVEL] ?: 1
                val curBest = p[Keys.BEST_COMBO] ?: 0
                var newXp = curXp + earned
                var newLv = curLv
                var need = xpNeeded(newLv)
                while(newXp >= need){ newXp -= need; newLv++; need = xpNeeded(newLv) }
                p[Keys.COINS] = curCoins + earned
                p[Keys.TAPS] = curTaps + 1
                p[Keys.XP] = newXp
                p[Keys.TOTAL_XP] = curTotal + earned
                p[Keys.LEVEL] = newLv
                p[Keys.LIFETIME] = (p[Keys.LIFETIME] ?: 0L) + earned
                p[Keys.BEST_COMBO] = maxOf(curBest, combo)
            }
        }
    }

    fun buy(type: String){
        viewModelScope.launch {
            ctx.dataStore.edit { p ->
                val coinsVal = p[Keys.COINS] ?: 0L
                val dl = p[Keys.DOUBLE] ?: 0
                val al = p[Keys.AUTO] ?: 0
                val cl = p[Keys.CRIT] ?: 0
                val sl = p[Keys.SPEED] ?: 0
                val cost = when(type){
                    "double" -> 500*(dl+1)
                    "auto" -> 1000*(al+1)
                    "critical" -> 800*(cl+1)
                    "speed" -> 600*(sl+1)
                    else -> Int.MAX_VALUE
                }
                if(coinsVal >= cost){
                    p[Keys.COINS] = coinsVal - cost
                    when(type){
                        "double" -> p[Keys.DOUBLE] = dl+1
                        "auto" -> p[Keys.AUTO] = al+1
                        "critical" -> p[Keys.CRIT] = cl+1
                        "speed" -> p[Keys.SPEED] = sl+1
                    }
                }
            }
        }
    }

    fun claimDaily(): Long {
        val now = System.currentTimeMillis()
        if(now - lastDaily.value < 24*60*60*1000) return 0
        val reward = 500L
        viewModelScope.launch { ctx.dataStore.edit { it[Keys.COINS] = (it[Keys.COINS] ?:0L)+reward; it[Keys.LAST_DAILY]=now } }
        return reward
    }
    fun canSpin() = System.currentTimeMillis() - lastSpin.value > 12*60*60*1000
    fun spin(): Int {
        if(!canSpin()) return 0
        val prize = listOf(50,100,200,500,1000).random()
        viewModelScope.launch { ctx.dataStore.edit { it[Keys.COINS]=(it[Keys.COINS]?:0L)+prize; it[Keys.LAST_SPIN]=System.currentTimeMillis() } }
        return prize
    }
    fun setDark(v:Boolean)=viewModelScope.launch { ctx.dataStore.edit { it[Keys.DARK]=v } }
    fun setSound(v:Boolean)=viewModelScope.launch { ctx.dataStore.edit { it[Keys.SOUND]=v } }
    fun setVib(v:Boolean)=viewModelScope.launch { ctx.dataStore.edit { it[Keys.VIB]=v } }
}
