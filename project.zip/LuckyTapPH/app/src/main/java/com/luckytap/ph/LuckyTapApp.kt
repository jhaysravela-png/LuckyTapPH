
package com.luckytap.ph
import android.app.Application
import com.google.android.gms.ads.MobileAds
class LuckyTapApp: Application(){
    override fun onCreate(){
        super.onCreate()
        MobileAds.initialize(this){}
    }
}
